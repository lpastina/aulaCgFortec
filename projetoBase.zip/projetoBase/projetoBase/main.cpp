#include <windows.h>
#include <GL/glut.h>
#include <GL/gl.h>

void init() {
    glClearColor(0.0, 0.0, 0.0, 1.0);
    gluOrtho2D(0, 800, 0, 600);   
}

void render() {
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_TRIANGLES);
    glColor3f(1.0, 0.0, 0.0); // Vermelho
    glVertex2i(200, 200);

    glColor3f(1.0, 0.0, 0.0); // Verde
    glVertex2i(600, 200);

    glColor3f(1.0, 0.0, 0.0); // Azul
    glVertex2i(400, 500);
    glEnd();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Janela Simples OpenGL");

    init();
    glutDisplayFunc(render);

    glutMainLoop();
    return 0;
}